package company;
import java.util.Scanner;
public class hirokikumazawa {
    public static void main(String[] args) {
        String[] qn;
        qn = new String[6];
        qn[0] = "今の気分の料理は何ですか？";
        qn[1] = "好きなスポーツは何ですか？";
        qn[2] = "好きな異性のタイプは何ですか？";
        qn[3] = "好きな髪形は何ですか？";
        qn[4] = "欲しいものは何ですか？";
        qn[5] = "世界の半分をくれてやろうか？";

        String[] as;
        as = new String[6];
        as[0] = "1: インド料理 2: イタリアン 3: フレンチ 4: 和食";
        as[1] = "1: 相撲 2: サッカー 3: 野球 4: 卓球 ";
        as[2] = "1: 世話焼き幼馴染系 2: クールな優等生系 3: 明るいドジっ子系 4: のんびり不思議系";
        as[3] = "1: 髪の毛はいらない・・・ 2: ベリーショート 3: ショート 4: ロング ";
        as[4] = "1: 家電製品 2: 彼氏or彼 3: 目の前を覆いつくす札束 4: 永遠の命 ";
        as[5] = "1: Yes 2: No 3: それはドラk・・・・ 4: 命を大事に";


        int b = 0;
        for (int i = 0; i < qn.length; i++) {
            System.out.println(qn[i]);
            System.out.println(as[i]);
            Scanner sa = new Scanner(System.in);
            int a = sa.nextInt();
            b = b + a;
            int c = qn.length;
            if ((a <= 4) && (i <= c - 2)) {
                System.out.println("次の問題へ");
            }
            else if((a <= 4) && (i == c - 1 )){
                if (b <= 7) {
                    System.out.println("相性は最悪です");
                }
                else if(b <= 12){
                    System.out.println("相性は普通です");
                }
                else if(b <= 16){
                    System.out.println("相性は良好です");
                }
                else if(b <= 24){
                    System.out.println("相性は最高です");
                }

            }
            else {
                System.out.println("1～4の番号を入力して下さい。");
                i = i - 1;
            }


        }
    }}



